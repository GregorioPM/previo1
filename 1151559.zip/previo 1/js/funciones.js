

$(document).ready(function(){    
    $('#btn-login').click(function(){        
               
        var usu = document.getElementById("email").value;
        var pass = document.getElementById("contra").value;
        var us= "admin";
        var pa= 1234;
        
        
        /*Guardando los datos en el LocalStorage*/
        if(usu == us) {
					if( pass== pa) {
						console.log(true);
						localStorage.setItem("usuario",usu);
						localStorage.setItem("password",pass);
					window.location="cartas.html";
					}
				}
        
        
        
    });  
    }); 